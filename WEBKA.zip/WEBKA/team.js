function f1(){
    var a;
    a = document.getElementById('tamable').style.display='none';
    return a;

}
function f2(){
    let a=document.getElementById('tamable').style.display='block';
    return a;
}