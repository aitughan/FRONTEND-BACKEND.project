<?php

$con = mysqli_connect("localhost","root","DARIGAICERIK","statistics") or die("Connection Error");


if($_SERVER['REQUEST_METHOD'] == 'POST')
{

    if(isset($_POST['submit']))
    {

        $v_name = mysqli_escape_string($con, $_POST['name']);
        $v_email = mysqli_escape_string($con, $_POST['email']);
        $v_pass = mysqli_escape_string($con, $_POST['pass']);

        function validation($form_data)
        {
            $form_data = trim( stripcslashes( htmlspecialchars( $form_data ) ) );
            return $form_data;
        }

        $name = validation($v_name);
        $email = validation($v_email);
        $pass = validation($v_pass);

        if(!empty($name) && !empty($email) && !empty($pass))
        {

            $check = "SELECT `u_email` FROM `user_detail` WHERE `u_email`='$email'";

            $check_query = mysqli_query($con, $check);

            if(mysqli_num_rows($check_query) > 0)
            {
                $msg = "This Email is Already Registered";
            }
            else
            {

                $hash_pass = password_hash($pass, PASSWORD_BCRYPT);

                $insert = "INSERT INTO `user_detail`(`u_name`,`u_email`,`u_pass`) VALUES('$name','$email','$hash_pass')";

                if(mysqli_query($con, $insert))
                {
                    header("Refresh:0");
                }
                else
                {
                    $msg = "You are not registered";
                }

            }

        }
        else
        {
            $msg = "Empty Field Found";
        }

    }

}


?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Now</title>
    <link href="bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body>


<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-6 text-center">
            <h1>Register Now / <a href="login.php">Login Now</a></h1>
            <form method="POST">
                <input type="text" name="name" placeholder="Enter Your Name" class="mt-3 w-100 form-control">
                <input type="email" name="email" placeholder="Enter Your Email" class="mt-3 mb-3 w-100 form-control">
                <input type="password" name="pass" placeholder="*******" class="mb-3 w-100 form-control">
                <input type="submit" name="submit" class="btn btn-lg btn-primary">
                <input type="reset" name="reset" class="btn btn-lg btn-primary">
            </form>
            <h4 class="mt-2" style="color:red;">
                <?php echo @$msg; ?>
            </h4>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/Fde/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
</body>
</html>