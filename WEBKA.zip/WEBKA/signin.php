<!DOCTYPE html>
<html lang="en>


<head>
    <title>ATLETICO DE MADRID</title>
    <meta charset="UTF-8">
<link href="bootstrap.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="atletiweb.css">
<script type="text/javascript" src="atletiweb.js"></script>

<header >
    <nav id="main">
        <ul>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/atletiweb.html"><img  src="logo.jpg" alt="logo" width="50px" heigth="30px"></a></li>
            <li ><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/signin.html"><h2>SIGN IN </h2></a></li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/team.html"><h2>FIRST TEAM</h2></a>
                <ul>
                    <li><a><h2>Squad</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/store.html"><h2>Store</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/latestnews.html"><h2>Latest News</h2></a></li>

                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/Academy.html" ><h2>ACADEMY</h2></a>
                <ul>
                    <li><a>U17</a></li>
                    <li><a>U19</a></li>
                    <li><a>Atleti B</a></li>
                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/club.html" ><h2>CLUB</h2></a><ul>
                <li><a>History</a></li>
                <li><a>Board and Directors</a></li>
                <li><a>Stadium</a></li>
            </ul></li>
        </ul>

</header>
</head>

<body style="color: black;background-color: white">
<br>
<br>
<br>
<br>
<br><br><br>
<br>
<br><br>
<br><br>
<br>
<br>
<br>
<br><div style="color white"></div>
<?php

session_start();

$con = mysqli_connect("localhost","root","DARIGAICERIK","statistics") or die("Connection Error");

if(!isset($_SESSION['name']) && !isset($_SESSION['email']) && !isset($_SESSION['pass']))
{
    header("location:login.php");
}

$name = $_SESSION['name'];
$email = $_SESSION['email'];
$pass = $_SESSION['pass'];

?>


<div class="container">
    <div class="row justify-content-center mt-5">
        <div style="color: black ;font-size: 40px">
            <h1>You Are Login In Our System</h1>
            <h3>Name is : <?php echo $name; ?></h3>
            <h3>Email is : <?php echo $email; ?></h3>
           <!-- <h3>Pass is : <?php echo $pass; ?></h3>-->
            <a href="signin.php?vid" class="btn btn-lg btn-danger">Logout</a>
            <a href="club.php" class="btn btn-lg btn-primary">Go to main page</a>
        </div>
    </div>
</div>


<?php

if(isset($_GET['vid']))
{
    session_destroy();

    header("location:login.php");
}

?>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>




</body>


<footer id="footer"><p style="text-align: center"><a href="https://www.instagram.com/atleticodemadrid/?hl=ru"><img width="100" height="50" src="instagram_icn%20(1).svg"></a><a href="https://twitter.com/atletienglish"><img  width="100" height="50" src="twitter_icn.svg"></a><a href="https://www.youtube.com/user/clubatleticodemadrid?sub_confirmation=1"><img width="100" height="50" src="youtube_icn.svg"> </a><a href="https://www.facebook.com/AtleticodeMadrid"><img width="100" height="50" src="facebook_icn.svg" </a> </p></footer>
