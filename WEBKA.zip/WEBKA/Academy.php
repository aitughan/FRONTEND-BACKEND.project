<!DOCTYPE html>
<html lang="en">


<head>
    <title>ATLETICO DE MADRID</title>
    <meta charset="UTF-8">
<script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css" href="atletiweb.css">
<script type="text/javascript" src="atletiweb.js"></script>

<header >
    <nav id="main">
        <ul>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/atletiweb.html"><img  src="logo.jpg" alt="logo" width="50px" heigth="30px"></a></li>
            <li ><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/signin.html"><h2>SIGN IN </h2></a></li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/team.html"><h2>FIRST TEAM</h2></a>
                <ul>
                    <li><a><h2>Squad</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/store.html"><h2>Store</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/latestnews.html"><h2>Latest News</h2></a></li>

                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/Academy.html" ><h2>ACADEMY</h2></a>
                <ul>
                    <li><a>U17</a></li>
                    <li><a>U19</a></li>
                    <li><a>Atleti B</a></li>
                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/club.html" ><h2>CLUB</h2></a><ul>
                <li><a>History</a></li>
                <li><a>Board and Directors</a></li>
                <li><a>Stadium</a></li>
            </ul></li>
        </ul>
    </nav>

</header>

</head><br>

<body style="background-color: white;color: black;" >
<br>
<br>
<br>
<div style="font-size: 40px">
<!--encapsulation--><?php
class Coach
{
    public $coach_name;
    public $coach_info;
    function __construct($co_name, $co_info)
    {
        $this->coach_name = $co_name;
        $this->coach_info = $co_info;
    }
    public function Coach_details()
    {
        echo "Coach name is $this->coach_name  $this->coach_info";
    }
}
$obj = new Coach("Burgous", " he worked as assistant to former club and country teammate Diego Simeone at Catania Calcio, Racing Club de Avellaneda and Atlético Madrid.");
echo $obj->Coach_details();
?>
</div>
<br>
<br>
<br>
<br>

<div style="text-align: center;;color: black;font-size: 50px">

<?php
$conn3=new mysqli('localhost','root','DARIGAICERIK','statistics');
if($conn3->connect_error){
    die("connection error".$conn3->connect_error);
}
$result=$conn3->query("SELECT fname,number FROM kids");
if($result->num_rows>0 ){
    while($row =$result->fetch_assoc()){
        echo $row['fname'].'      '.$row['number'].'<br>';
    }
}
?>
</div>
</body>
<br>
<br>
<br>
<br>
<br>
<br>
<br>



<footer id="footer"><p style="text-align: center"><a href="https://www.instagram.com/atleticodemadrid/?hl=ru"><img width="100" height="50" src="instagram_icn%20(1).svg"></a><a href="https://twitter.com/atletienglish"><img  width="100" height="50" src="twitter_icn.svg"></a><a href="https://www.youtube.com/user/clubatleticodemadrid?sub_confirmation=1"><img width="100" height="50" src="youtube_icn.svg"> </a><a href="https://www.facebook.com/AtleticodeMadrid"><img width="100" height="50" src="facebook_icn.svg"></a> </p></footer></body>
