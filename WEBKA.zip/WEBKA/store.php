<!DOCTYPE html>
<html lang="en>


<head>
    <title>ATLETICO DE MADRID</title>
    <meta charset="UTF-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="atletiweb.css">
<script type="text/javascript" src="atletiweb.js"></script>

<header >
    <nav id="main">
        <ul>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/atletiweb.html"><img  src="logo.jpg" alt="logo" width="50px" heigth="30px"></a></li>
            <li ><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/signin.html"><h2>SIGN IN </h2></a></li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/team.html"><h2>FIRST TEAM</h2></a>
                <ul>
                    <li><a><h2>Squad</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/store.html"><h2>Store</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/latestnews.html"><h2>Latest News</h2></a></li>

                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/Academy.html" ><h2>ACADEMY</h2></a>
                <ul>
                    <li><a>U17</a></li>
                    <li><a>U19</a></li>
                    <li><a>Atleti B</a></li>
                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/club.html" ><h2>CLUB</h2></a><ul>
                <li><a>History</a></li>
                <li><a>Board and Directors</a></li>
                <li><a>Stadium</a></li>
            </ul></li>
        </ul>

</header>
</head>


<br>
<br>
<br>
<body style="color: black;background-color: white;font-size: 40px">
<div class="all">
    <input checked="" type="radio" name="respond" id="desktop">
    <article id="slider">
        <input checked="" type="radio" name="slider" id="switch1">
        <input type="radio" name="slider" id="switch2">
        <input type="radio" name="slider" id="switch3">

        <div id="slides">
            <div id="overflow">
                <div class="image">
                    <article><img src="tlm_en.jpg"></article>
                    <article><img src="tlm_en2.jpg"></article>
                    <article><img src="tlm_en3.jpg"></article>


                </div>
            </div>
        </div>
        <div id="controls">
            <label for="switch1"></label>
            <label for="switch2"></label>
            <label for="switch3"></label>

        </div>
        <div id="active">
            <label for="switch1"></label>
            <label for="switch2"></label>
            <label for="switch3"></label>

        </div>
    </article>
</div>
</th>
<div class="shop">
    <h1>OUR FAN SHOP</h1>
    <form class="formClass" action="myPage.html">

        <input type="radio" id="r1" name="Das" onclick="button_1()" >English
        <input type="radio" id="r2" name="Das" onclick="button_2()" >Espanol
    </form>

    <h1 id="h1">TIENDA:</h1>


    <main style="
    text-align: center"> <nav id="nav" ><h3>EQUIPO</h3></nav>
        <table>
        <div id="div1">
            <div class="tshirt">
            <section id="section1">
                <p id = "p1">
                    camiseta:

                </p>
                <img src="tshirt.jpg" width="100" height="100">
                <p>$48.97-$94.95</p>
                <?php
                interface Store {
                    public function calcTask();
                }
                class Tshirt implements Store {
                    private $radius;
                    public function __construct($dolar){
                        $this -> dolar = $dolar;
                    }
                    public function calcTask(){
                        return $this -> dolar * 400;
                    }
                }


                $mycirc = new Tshirt(48);

                echo $mycirc->calcTask()."TG";

                ?>
            </section>
        </div>
            <br>
            <br>
        <div class="short">
            <p id = "p2">
                pantalones cortos:
            </p>
            <img src="shorts.jfif" width="300%" height="300%">
            <p> $19.99-$32.85 </p>
            <?php

            class Shtany implements Store {
                private $radius;
                public function __construct($dolar){
                    $this -> dolar = $dolar;
                }
                public function calcTask(){
                    return $this -> dolar * 400;
                }
            }


            $mycirc = new Shtany(20);

            echo $mycirc->calcTask()."TG";

            ?>

        </div>
            <br>
            <br>
            <br>
        <div >

            <aside>bolsa de deporte:</aside>
            <img src="bag.jpg" width="100" height="100">
            <p>$45.00</p>
            <?php

            class Bag implements Store {
                private $radius;
                public function __construct($dolar){
                    $this -> dolar = $dolar;
                }
                public function calcTask(){
                    return $this -> dolar * 400;
                }
            }


            $mycirc = new Bag(45);

            echo $mycirc->calcTask()."TG";

            ?>

        </div>
        </table>

</div>
</body>
<footer id="footer"><p style="text-align: center;color:white;font-size: 70px"><a href="https://www.instagram.com/atleticodemadrid/?hl=ru"><img width="100" height="50" src="instagram_icn%20(1).svg"></a><a href="https://twitter.com/atletienglish"><img  width="100" height="50" src="twitter_icn.svg"></a><a href="https://www.youtube.com/user/clubatleticodemadrid?sub_confirmation=1"><img width="100" height="50" src="youtube_icn.svg"> </a><a href="https://www.facebook.com/AtleticodeMadrid"><img width="100" height="50" src="facebook_icn.svg" </a> </p></footer>

