<!DOCTYPE html>
<html lang="en">
<head>

    <title>ATLETICO DE MADRID</title>
    <meta charset="UTF-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="atletiweb.css">
<script type="text/javascript" src="atletiweb.js"></script>

<header >
    <nav id="main">
        <ul>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/atletiweb.html"><img  src="logo.jpg" alt="logo" width="50px" heigth="30px"></a></li>
            <li ><a href="fi    le:///C:/Users/AITUGANG/Desktop/WEBKA/signin.html"><h2>SIGN IN </h2></a></li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/team.html"><h2>FIRST TEAM</h2></a>
                <ul>
                    <li><a><h2>Squad</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/store.html"><h2>Store</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/latestnews.html"><h2>Latest News</h2></a></li>

                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/Academy.html" ><h2>ACADEMY</h2></a>
                <ul>
                    <li><a>U17</a></li>
                    <li><a>U19</a></li>
                    <li><a>Atleti B</a></li>
                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/club.html" ><h2>CLUB</h2></a><ul>
                    <li><a>History</a></li>
                    <li><a>Board and Directors</a></li>
                    <li><a>Stadium</a></li>
                </ul></li>
        </ul>
    </nav>
</header>
</head>


<br>
<br>
<br>
<body >
<div style="color: black;background-color: white;font-size: 40px;text-align: center">
<?php
// Abstract
abstract class Director {
    public $name;
    public function __construct($name) {
        $this->name = $name;
    }
    abstract public function intro() : string;
}


class Enrique extends Director{
    public function intro() : string {
        return "President of the Club $this->name!";
    }
}

class Diego extends Director {
    public function intro() : string {
        return "Head coach $this->name!";
    }
}


// Create objects from the child classes
$enr = new Enrique("Enrique Sareso");
echo $enr->intro();
echo "<br><img src='enriquecerezo-atleticomadrid.jpeg' ><br>";

$diego = new Diego("Diego Simeone");
echo $diego->intro();
echo "<br><img src='coach.jpg' style='width: 1200px;height: 675px'><br>";


?>
</div>
</body>
<footer id="footer"><p style="text-align: center;color:white;font-size: 70px"><a href="https://www.instagram.com/atleticodemadrid/?hl=ru"><img width="100" height="50" src="instagram_icn%20(1).svg"></a><a href="https://twitter.com/atletienglish"><img  width="100" height="50" src="twitter_icn.svg"></a><a href="https://www.youtube.com/user/clubatleticodemadrid?sub_confirmation=1"><img width="100" height="50" src="youtube_icn.svg"> </a><a href="https://www.facebook.com/AtleticodeMadrid"><img width="100" height="50" src="facebook_icn.svg" </a> </p></footer>
</html>
