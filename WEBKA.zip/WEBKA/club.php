<!DOCTYPE html>
<html lang="en>


<head>
    <title>ATLETICO DE MADRID</title>
    <meta charset="UTF-8">
<style>
    .grid-container {
        display: grid;
        grid-template-columns: auto auto auto;
        background-color: #2196F3;
        padding: 10px;
    }
    .grid-item {
        background-color: rgba(255, 255, 255, 0.8);
        border: 1px solid rgba(0, 0, 0, 0.8);
        padding: 20px;
        font-size: 30px;
        text-align: center;
    }
    table{
        border-collapse: collapse;
        width:100%;

        color: #588c7e;
        font-family: monospace;
        font-size:50px;
        text-align: center;
    }
    th{
        height: 100px;
        background-color: #588c7e;
        color:white;
    }
    tr:nth-child(even){background-color: #f2f2f2}
</style>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="atletiweb.css">
<script type="text/javascript" src="atletiweb.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<header >
    <nav id="main">
        <ul>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/atletiweb.html"><img  src="logo.jpg" alt="logo" width="50px" heigth="30px"></a></li>
            <li ><a href="signin.php"><h2>SIGN IN </h2></a></li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/team.html"><h2>FIRST TEAM</h2></a>
                <ul>
                    <li><a href="Squad.php"><h2>Squad</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/store.html"><h2>Store</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/latestnews.html"><h2>Latest News</h2></a></li>

                </ul>
            </li>
            <li><a href="Academy.php" ><h2>ACADEMY</h2></a>
                <ul>
                    <li><a>U17</a></li>
                    <li><a>U19</a></li>
                    <li><a>Atleti B</a></li>
                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/club.html" ><h2>CLUB</h2></a><ul>
                <li><a>History</a></li>
                <li><a href="directros.php">Board and Directors</a></li>
                <li><a>Stadium</a></li>
            </ul></li>
        </ul>

</header>
</head>
<body style="background-color: white;color: black">
<div class="brd2"><p><h3><span class="letter">A</span> tlético Madrid are the third most successful club in Spanish football – behind Real Madrid and Barcelona. Atlético have won La Liga on 10 occasions, including a league and cup double in 1996; the Copa del Rey on 10 occasions; two Supercopas de España and one Copa Eva Duarte; in Europe, they won the European Cup Winners' Cup in 1962, were runners-up in 1963 and 1986, were Champions League runners-up in 1974, 2014 and 2016, won the Europa League in 2010, 2012 and 2018, and won the UEFA Super Cup in 2010, 2012 and 2018 as well as the 1974 Intercontinental Cup.<!--small definition about club--></h3><p style="text-align: center" >COACH: <a href="https://ru.wikipedia.org/wiki/%D0%A1%D0%B8%D0%BC%D0%B5%D0%BE%D0%BD%D0%B5,_%D0%94%D0%B8%D0%B5%D0%B3%D0%BE">DIEGO SIMEONE</a></p><br><b></b> </p>
</div>
<hr>
<div style="color: white;font-size: 40px;text-align: center">
    <p> Next game vs Atletic Bilbao</p>
    <?php
    $json=['14.06.2020'];
    echo json_encode($json);
    ?>

</div>
<main class="main2">
<br>
    <br>
    <br>
    <br>
    <br>

<div class="history">
<dl>
    <dt><h1 style="text-align: center" >HISTORY</h1> </dt>
    <dd class="dd2">The club was founded on 26 April 1903 as Athletic Club Sucursal de Madrid by three Basque students living in Madrid. These founders saw the new club as a youth branch of their childhood team, Athletic Bilbao who they had just seen win the 1903 Copa del Rey Final in the city. In 1904, they were joined by dissident members of Real Madrid. The side began playing in blue and white halved shirts, the then colours of Athletic Bilbao, but by 1911, both the Bilbao and Madrid teams were playing in their current colours of red and white stripes. Some believe the change came about because red and white striped tops were the cheapest to make, as the same combination was used to make ticking for mattresses, and the unused cloth was easily converted into football shirts. This contributed to the club's nickname, Los Colchoneros.<br>


        An Athletic Madrid lineup of 1911 in their new red and white kit.<br>
        However, another explanation is that both Athletic Bilbao and Athletic Madrid used to buy Blackburn Rovers' blue and white kits in England. In late 1909, Juanito Elorduy, a former player and member of the board of Athletic Madrid, went to England to buy kits for both teams but failed to find Blackburn kits to purchase; he instead bought the red and white shirts of Southampton (the club from the port city which was his embarkation point back to Spain). Athletic Madrid adopted the red and white shirt, leading to them being known as Los Rojiblancos, but opted to keep their existing blue shorts whereas the Bilbao team switched to new black shorts. Athletic Bilbao won the 1911 Copa del Rey Final using several 'borrowed' players from Athletic Madrid, including Manolón who scored one of their goals.<br>

        Athletic's first ground, the Ronda de Vallecas, was in the eponymous working-class area on the south side of the city. In 1919, the Compañía Urbanizadora Metropolitana—the company that ran the underground communication system in Madrid—acquired some land, near the Ciudad Universitaria. In 1921, Athletic Madrid became independent of parent-club Athletic Bilbao and moved into a 35,800-seater stadium built by the company, the Estadio Metropolitano de Madrid. The Metropolitano was used until 1966, when they moved to the new Estadio Vicente Calderón. After the move, the Metropolitano was demolished and was replaced with university buildings and an office block belonging to the company ENUSA.<br>

        During the 1920s, Athletic won the Campeonato del Centro three times and were Copa del Rey runners-up in 1921, where they faced parent club Athletic Bilbao, as they would again in 1926. Based on these successes, in 1928 they were invited to join the Primera División of the inaugural La Liga played the following year. During their debut La Liga campaign, the club were managed by Fred Pentland, but after two seasons they were relegated to Segunda División. They briefly returned to La Liga in 1934 but were relegated again in 1936 after Josep Samitier took over in mid-season from Pentland. The Spanish Civil War gave Los Colchoneros a reprieve, as Real Oviedo was unable to play due to the destruction of their stadium during the bombings. Thus, both La Liga and Athletic's relegation were postponed, the latter by winning a playoff against Osasuna, champion of the Segunda División tournament.<br></dd>
</dl>
<p style="text-align: center"><img src="1911.jpg" alt="HISTORY " width="500" height="300"> </p>
</div>
    </main>

<main class="main3">
<div class="stadium">
<dl>
    <dt><h1 style="text-align: center">STADIUM</h1></dt>
    <dd class="dd3">The club played their home games at the 54,990 seat Estadio Vicente Calderón in southern Madrid until 2017. Before this, the club played originally at the Ronda de Vallecas until 1923. After the completion of the Estadio Metropolitano de Madrid in 1923, the club moved there until the Vicente Calderón was finished in 1966.<br>
        The club now plays in the renovated Wanda Metropolitano, which was expanded from a 20,000 seat capacity to 68,000 after it was used for Madrid's failed bid to host the 2016 Summer Olympics. The Vicente Calderón will be demolished, and replaced by a waterfront park at the banks of the Manzanares River in Madrid. On 17 September 2017, the Wanda Metropolitano hosted its first competitive match against Malaga CF, in which the King attended. Antoine Griezmann scored the club's first goal at the stadium.</dd>
</dl>
<h2><p style="text-align: center"> WANDA METROPALITANO</p></h2>
<p style="text-align: center"><img width="600px" heigth="400px" src="wanda.jpg"></p>
</div>
</main>
<p style="font-size: 100px;color: black;text-align: center">Trophies</p>
<p style="text-align: center"><img src="trophies.JPG" width="700px" height="300"></p>
<center>
<div style="color: red;text-align: center;font-size: 70px">
    <table>


    <?php



    $conn2=mysqli_connect("localhost","root","DARIGAICERIK","statistics");
    if($conn2->connect_error){
        die("Connection failed:".$conn2->connect_error);
    }
    $sql="SELECT trophy from trophies";
    $result=$conn2->query($sql);
    if($result->num_rows>0){
        while($row=$result->fetch_assoc()){
            echo "<tr><td>".$row["trophy"]."</td></tr>";
        }
        echo "</table>";
    }else{
        echo "0 results";
    }
    $conn2->close();

    ?>
    </table>
    <p style="text-align: center;color: white;font-size: 70px">La liga Table</p>
    <table>
        <tr>
            <th>Club</th>
            <th>Points</th>

        </tr>
    <?php



    $conn1=mysqli_connect("localhost","root","DARIGAICERIK","statistics");
    if($conn1->connect_error){
        die("Connection failed:".$conn1->connect_error);
    }
    $sql="SELECT name,points from laliga";
    $result=$conn1->query($sql);
    if($result->num_rows>0){
        while($row=$result->fetch_assoc()){
            echo "<tr><td>".$row["name"]."</td><td>".$row["points"]."</td></tr>";
        }
        echo "</table>";
    }else{
        echo "0 results";
    }
    $conn1->close();

    ?>
    </table>
</div>
</center>
<!--<dl>
    <dt><h1 STYLE="text-align: center">TROPHIES</h1></dt>
    <ol>
        <p style="text-align: center"> <button id="f3" onclick="f3()">SHOW TROPHIES</button></p>
    </ol>
</dl>-->

<hr>
<footer id="footer"><p style="text-align: center"><a href="https://www.instagram.com/atleticodemadrid/?hl=ru"><img width="100" height="50" src="instagram_icn%20(1).svg"></a><a href="https://twitter.com/atletienglish"><img  width="100" height="50" src="twitter_icn.svg"></a><a href="https://www.youtube.com/user/clubatleticodemadrid?sub_confirmation=1"><img width="100" height="50" src="youtube_icn.svg"> </a><a href="https://www.facebook.com/AtleticodeMadrid"><img width="100" height="50" src="facebook_icn.svg" </a> </p></footer>
</body>
</html>