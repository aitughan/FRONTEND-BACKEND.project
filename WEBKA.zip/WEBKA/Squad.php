<?php

$connect = mysqli_connect("localhost", "root", "DARIGAICERIK", "statistics");
function fill_brand($connect)
{
    $output = '';
    $sql = "SELECT * FROM position";
    $result = mysqli_query($connect, $sql);
    while($row = mysqli_fetch_array($result))
    {
        $output .= '<option value="'.$row["brand_id"].'">'.$row["brand_name"].'</option>';
    }
    return $output;
}
function fill_product($connect)
{
    $output = '';
    $sql = "SELECT * FROM player";
    $result = mysqli_query($connect, $sql);
    while($row = mysqli_fetch_array($result))
    {
        $output .= '<div class="col-md-3">';
        $output .= '<div style="border:1px solid #ccc; padding:20px; margin-bottom:20px;">'.$row["product_name"].'';
        $output .=     '</div>';
        $output .=     '</div>';
    }
    return $output;
}
?>
<!DOCTYPE html>
<html lang="en>


<head>
    <title>ATLETICO DE MADRID</title>
    <meta charset="UTF-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="atletiweb.css">
<script type="text/javascript" src="atletiweb.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<style>
    .grid-container {
        display: grid;
        grid-template-columns: auto auto auto;
        background-color: #2196F3;
        padding: 10px;
    }
    .grid-item {
        background-color: rgba(255, 255, 255, 0.8);
        border: 1px solid rgba(0, 0, 0, 0.8);
        padding: 20px;
        font-size: 30px;
        text-align: center;
    }
    table{
        border-collapse: collapse;
        width:100%;

        color: #588c7e;
        font-family: monospace;
        font-size:50px;
        text-align: center;
    }
    th{
        height: 100px;
        background-color: #588c7e;
        color:white;
    }
    tr:nth-child(even){background-color: #f2f2f2}
</style>
<header >
    <nav id="main">
        <ul>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/atletiweb.html"><img  src="logo.jpg" alt="logo" width="50px" heigth="30px"></a></li>
            <li ><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/signin.html"><h2>SIGN IN </h2></a></li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/team.html"><h2>FIRST TEAM</h2></a>
                <ul>
                    <li><a><h2>Squad</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/store.html"><h2>Store</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/latestnews.html"><h2>Latest News</h2></a></li>

                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/Academy.html" ><h2>ACADEMY</h2></a>
                <ul>
                    <li><a>U17</a></li>
                    <li><a>U19</a></li>
                    <li><a>Atleti B</a></li>
                </ul>
            </li>
            <li><a href="club.php" ><h2>CLUB</h2></a><ul>
                <li><a>History</a></li>
                <li><a>Board and Directors</a></li>
                <li><a>Stadium</a></li>
            </ul></li>
        </ul>
    </nav>
</header>
</head>
<body style="color: black;background-color: white">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br /><br />

<div class="container">
    <h3>
        <select name="brand" id="brand">
            <option value="">Show All PLAYERS</option>
            <?php echo fill_brand($connect); ?>
        </select>
        <br /><br />
        <div class="row" id="show_product">
            <?php echo fill_product($connect);?>
        </div>
    </h3>
</div>


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="grid-container">
    <div class="grid-item"><a href="Oblak.php"> <img src="13_OBLAK.jpg"><br>Jan Oblak</a></div>
    <div class="grid-item"><img src="2_GIMENEZ.jpg"><br>Mario Gimenez</div>
    <div class="grid-item"><img src="6_KOKE.jpg"><br>Jorge Koke </div>
    <div class="grid-item"><img src="8_SAUL.jpg"><br>Saul Niguez</div>
    <div class="grid-item"><a href="Joao.php"> <img src="7_JOAO.jpg"><br>Joao Felix</a></div>
    <div class="grid-item"><img src="19_COSTA.jpg"><br>Diego Costa </div>

</div>
<p style="text-align: center;color: white;font-size: 70px">Statistics</p>
<table>
    <tr>
        <th>Player</th>
        <th>Goals</th>
        <th>Assists</th>
    </tr>
    <?php


    $hostname_db = "localhost";
    $database_db = "statistics";
    $username_db = "root";
    $password_db = "DARIGAICERIK";
    $conn = mysqli_connect($hostname_db, $username_db, $password_db,$database_db);
try{
     if ($conn = mysqli_connect($hostname_db, $username_db, $password_db,$database_db))
    {
        echo "connected";
    }
    else
    {
        throw new Exception('Unable to connect ');
    }
}
catch(Exception $e)
{
    echo $e->getMessage();
}
    $sql="SELECT name,goals,assists from statistics";
    $result=$conn->query($sql);
    if($result->num_rows>0){
        while($row=$result->fetch_assoc()){
            echo "<tr><td>".$row["name"]."</td><td>".$row["goals"]."</td><td>".$row["assists"]."</td></tr>";
        }
        echo "</table>";
    }
    else{
        echo "0 result";
    }

    $conn->close();
    ?>

</table>
</body>
<footer id="footer"><p style="text-align: center;color: white;font-size: 70px">Created By Aitugan<a href="https://www.instagram.com/atleticodemadrid/?hl=ru"><img width="100" height="50" src="instagram_icn%20(1).svg"></a><a href="https://twitter.com/atletienglish"><img  width="100" height="50" src="twitter_icn.svg"></a><a href="https://www.youtube.com/user/clubatleticodemadrid?sub_confirmation=1"><img width="100" height="50" src="youtube_icn.svg"> </a><a href="https://www.facebook.com/AtleticodeMadrid"><img width="100" height="50" src="facebook_icn.svg" ></a> </p></footer>
</html>
<script>
    $(document).ready(function(){
        $('#brand').change(function(){
            var brand_id = $(this).val();
            $.ajax({
                url:"load_data.php",
                method:"POST",
                data:{brand_id:brand_id},
                success:function(data){
                    $('#show_product').html(data);
                }
            });
        });
    });
</script>