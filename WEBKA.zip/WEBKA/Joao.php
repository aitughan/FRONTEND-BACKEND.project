<!DOCTYPE html>
<html lang="en>


<head>
    <title>ATLETICO DE MADRID</title>
    <meta charset="UTF-8">

<link rel="stylesheet" type="text/css" href="atletiweb.css">
<script type="text/javascript" src="atletiweb.js"></script>
<header >
    <nav id="main">
        <ul>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/atletiweb.html"><img  src="logo.jpg" alt="logo" width="50px" heigth="30px"></a></li>
            <li ><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/signin.html"><h2>SIGN IN </h2></a></li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/team.html"><h2>FIRST TEAM</h2></a>
                <ul>
                    <li><a><h2>Squad</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/store.html"><h2>Store</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/latestnews.html"><h2>Latest News</h2></a></li>

                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/Academy.html" ><h2>ACADEMY</h2></a>
                <ul>
                    <li><a>U17</a></li>
                    <li><a>U19</a></li>
                    <li><a>Atleti B</a></li>
                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/club.html" ><h2>CLUB</h2></a><ul>
                    <li><a>History</a></li>
                    <li><a>Board and Directors</a></li>
                    <li><a>Stadium</a></li>
                </ul></li>
        </ul>
    </nav>
</header>
</head>
<body >
<br>
<br>
<br>
<br>
<br>
<br>
<div style="color :white;font-size: 40px;padding: 30px;margin: 20px;text-align: center">
    <img src="BUSTOS_JOAO.png" >
    <br>
    <?php

    class Player
    {
        public $name;
        public $info;

        public function __construct($name, $info)
        {
            $this->name = $name;
            $this->info = $info;

        }

        public function intro()
        {
            echo "this animal is {$this->name} ,{$this->info}.";
        }
    }

    class Joao extends Player
    {
        public function __construct($name, $info)
        {
            $this->name = $name;
            $this->info = $info;

        }

        public function intro()
        {
            echo "The Striker is {$this->name},{$this->info}.";
        }
    }
    $joao=new Joao("Joao","On 3 July 2019, Félix signed a seven-year contract with Spanish club Atlético Madrid for a transfer fee of €126 million (£113 million), the third highest sum ever paid in football[31] (this was also Benfica's biggest transfer and Atlético's most expensive signing ever) as well as the second highest fee ever paid for a teenager (after Kylian Mbappé), with the Spanish club initially paying €30 million and the rest €96 million via installments, thus surpassing Félix's €120 million release clause, and with Benfica paying €12 million in mediation services.[32][33][34] Upon his arrival to the club he was handed the number 7 shirt, previously worn by Antoine Griezmann.[35][36]");
    $joao->intro();
    ?>
</div>

</body>
<footer id="footer"><p style="text-align: center;color: white;font-size: 70px">Created By Aitugan<a href="https://www.instagram.com/atleticodemadrid/?hl=ru"><img width="100" height="50" src="instagram_icn%20(1).svg"></a><a href="https://twitter.com/atletienglish"><img  width="100" height="50" src="twitter_icn.svg"></a><a href="https://www.youtube.com/user/clubatleticodemadrid?sub_confirmation=1"><img width="100" height="50" src="youtube_icn.svg"></a><a href="https://www.facebook.com/AtleticodeMadrid"><img width="100" height="50" src="facebook_icn.svg" ></a> </p></footer>