<!DOCTYPE html>
<html lang="en>


<head>
    <title>ATLETICO DE MADRID</title>
    <meta charset="UTF-8">

<link rel="stylesheet" type="text/css" href="atletiweb.css">
<script type="text/javascript" src="atletiweb.js"></script>
<header >
    <nav id="main">
        <ul>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/atletiweb.html"><img  src="logo.jpg" alt="logo" width="50px" heigth="30px"></a></li>
            <li ><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/signin.html"><h2>SIGN IN </h2></a></li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/team.html"><h2>FIRST TEAM</h2></a>
                <ul>
                    <li><a><h2>Squad</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/store.html"><h2>Store</h2></a></li>
                    <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/latestnews.html"><h2>Latest News</h2></a></li>

                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/Academy.html" ><h2>ACADEMY</h2></a>
                <ul>
                    <li><a>U17</a></li>
                    <li><a>U19</a></li>
                    <li><a>Atleti B</a></li>
                </ul>
            </li>
            <li><a href="file:///C:/Users/AITUGANG/Desktop/WEBKA/club.html" ><h2>CLUB</h2></a><ul>
                    <li><a>History</a></li>
                    <li><a>Board and Directors</a></li>
                    <li><a>Stadium</a></li>
                </ul></li>
        </ul>
    </nav>
</header>
</head>
<body >
<br>
<br>
<br>
<br>
<br>
<br>
<div style="color :white;font-size: 40px;padding: 30px;margin: 20px;text-align: center">
    <img src="BUSTOS_OBLAK.png" >
    <br>
<?php

class Player
{
    public $name;
    public $info;

    public function __construct($name, $info)
    {
        $this->name = $name;
        $this->info = $info;

    }

    public function intro()
    {
        echo "this animal is {$this->name} ,{$this->info}.";
    }
}

class Oblak extends Player
{
    public function __construct($name, $info)
    {
        $this->name = $name;
        $this->info = $info;

    }

    public function intro()
    {
        echo "The Goalkeeper is {$this->name},{$this->info}.";
    }
}
$oblak=new Oblak("Oblak","On 16 July 2014, Atlético Madrid announced they had reached an agreement with Benfica for the transfer of Oblak, pending a medical examination.[22] Atlético paid €16 million for the Slovenian player,[23][24] making him the most expensive goalkeeper in La Liga history.[25] Oblak moved to Madrid on a six-year deal as a replacement for Thibaut Courtois, who had returned to play for his parent club Chelsea following his loan expiration.[26][27] During his presentation, on 22 July 2014, Oblak said, \"I don't come to replace anyone. I come as another player. I'm here along with the rest of the players and goalkeepers. I'll do everything in my power to defend this shirt and achieve great results this season. I will do everything in my hand to help the team.");
$oblak->intro();
?>
</div>
</body>
<footer id="footer"><p style="text-align: center;color: white;font-size: 70px">Created By Aitugan<a href="https://www.instagram.com/atleticodemadrid/?hl=ru"><img width="100" height="50" src="instagram_icn%20(1).svg"></a><a href="https://twitter.com/atletienglish"><img  width="100" height="50" src="twitter_icn.svg"></a><a href="https://www.youtube.com/user/clubatleticodemadrid?sub_confirmation=1"><img width="100" height="50" src="youtube_icn.svg"> </a><a href="https://www.facebook.com/AtleticodeMadrid"><img width="100" height="50" src="facebook_icn.svg" ></a> </p></footer>